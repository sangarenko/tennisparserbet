import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    // First get players without history (lightweight)
    const players = await db.player.findMany({
      orderBy: { winRate: 'desc' },
    })

    // Add computed stats
    const playersWithStats = players.map((player) => {
      const totalMatches = player.wins + player.losses
      return {
        id: player.id,
        name: player.name,
        country: player.country,
        rank: player.rank,
        wins: player.wins,
        losses: player.losses,
        winRate: player.winRate,
        avgOdds: player.avgOdds,
        totalMatches,
        updatedAt: player.updatedAt,
      }
    })

    return NextResponse.json({ players: playersWithStats })
  } catch (error) {
    console.error('Failed to fetch players:', error)
    return NextResponse.json(
      { error: 'Failed to fetch players' },
      { status: 500 }
    )
  }
}
