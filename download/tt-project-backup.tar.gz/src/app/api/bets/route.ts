import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const bets = await db.bet.findMany({
      include: { match: true },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ bets })
  } catch (error) {
    console.error('Failed to fetch bets:', error)
    return NextResponse.json(
      { error: 'Failed to fetch bets' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { matchId, predictedWinner, odds, stake } = body

    if (!matchId) {
      return NextResponse.json({ error: 'matchId is required' }, { status: 400 })
    }
    if (!predictedWinner || !['player1', 'player2'].includes(predictedWinner)) {
      return NextResponse.json(
        { error: 'predictedWinner must be "player1" or "player2"' },
        { status: 400 }
      )
    }
    if (!odds || odds <= 1) {
      return NextResponse.json(
        { error: 'odds must be greater than 1' },
        { status: 400 }
      )
    }
    if (!stake || stake <= 0) {
      return NextResponse.json(
        { error: 'stake must be greater than 0' },
        { status: 400 }
      )
    }

    const match = await db.match.findUnique({ where: { id: matchId } })
    if (!match) {
      return NextResponse.json({ error: 'Match not found' }, { status: 404 })
    }

    const bet = await db.bet.create({
      data: {
        matchId,
        predictedWinner,
        odds: parseFloat(odds),
        stake: parseFloat(stake),
        potentialWin: parseFloat(stake) * parseFloat(odds),
        result: 'pending',
      },
    })

    return NextResponse.json({ bet }, { status: 201 })
  } catch (error) {
    console.error('Failed to create bet:', error)
    return NextResponse.json(
      { error: 'Failed to create bet' },
      { status: 500 }
    )
  }
}
