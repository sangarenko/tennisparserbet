import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const source = searchParams.get('source')
    const limit = parseInt(searchParams.get('limit') || '50')
    const offset = parseInt(searchParams.get('offset') || '0')

    const where: Record<string, unknown> = {}
    if (status) where.status = status
    if (source) where.source = source

    const matches = await db.match.findMany({
      where,
      include: {
        odds: true,
        predictions: true,
      },
      orderBy: { startTime: 'desc' },
      take: limit,
      skip: offset,
    })

    const total = await db.match.count({ where })

    return NextResponse.json({
      matches,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + matches.length < total,
      },
    })
  } catch (error) {
    console.error('Failed to fetch matches:', error)
    return NextResponse.json(
      { error: 'Failed to fetch matches' },
      { status: 500 }
    )
  }
}
