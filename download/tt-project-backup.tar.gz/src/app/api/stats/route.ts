import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const allBets = await db.bet.findMany({
      include: { match: true },
      orderBy: { createdAt: 'desc' },
    })

    const settledBets = allBets.filter(
      (b) => b.result === 'win' || b.result === 'loss'
    )
    const pendingBets = allBets.filter((b) => b.result === 'pending' || b.result === null)
    const voidBets = allBets.filter((b) => b.result === 'void')

    const wins = settledBets.filter((b) => b.result === 'win')
    const losses = settledBets.filter((b) => b.result === 'loss')

    const totalBets = allBets.length
    const totalWins = wins.length
    const totalLosses = losses.length
    const totalPending = pendingBets.length

    const winRate = settledBets.length > 0
      ? (totalWins / settledBets.length) * 100
      : 0

    const totalStaked = allBets.reduce((sum, b) => sum + b.stake, 0)
    const totalPayout = allBets.reduce((sum, b) => sum + b.payout, 0)
    const profit = totalPayout - totalStaked
    const roi = totalStaked > 0 ? (profit / totalStaked) * 100 : 0

    // Calculate current streak from most recent settled bets
    let currentStreak = 0
    const settledByDate = settledBets.sort(
      (a, b) => (b.settledAt?.getTime() ?? 0) - (a.settledAt?.getTime() ?? 0)
    )
    if (settledByDate.length > 0) {
      const firstResult = settledByDate[0].result
      if (firstResult === 'win') {
        for (const bet of settledByDate) {
          if (bet.result === 'win') currentStreak++
          else break
        }
      } else {
        for (const bet of settledByDate) {
          if (bet.result === 'loss') currentStreak--
          else break
        }
      }
    }

    // Calculate best win streak
    let bestStreak = 0
    let tempStreak = 0
    for (const bet of settledByDate) {
      if (bet.result === 'win') {
        tempStreak++
        bestStreak = Math.max(bestStreak, tempStreak)
      } else {
        tempStreak = 0
      }
    }

    // Average confidence from predictions
    const predictions = await db.prediction.findMany()
    const avgConfidence = predictions.length > 0
      ? predictions.reduce((sum, p) => sum + p.confidence, 0) / predictions.length
      : 0

    // Average odds from bets
    const avgOdds = allBets.length > 0
      ? allBets.reduce((sum, b) => sum + b.odds, 0) / allBets.length
      : 0

    return NextResponse.json({
      totalBets,
      wins: totalWins,
      losses: totalLosses,
      pending: totalPending,
      void: voidBets.length,
      winRate: Math.round(winRate * 100) / 100,
      roi: Math.round(roi * 100) / 100,
      totalStaked: Math.round(totalStaked * 100) / 100,
      totalPayout: Math.round(totalPayout * 100) / 100,
      profit: Math.round(profit * 100) / 100,
      currentStreak,
      bestStreak,
      avgConfidence: Math.round(avgConfidence * 100) / 100,
      avgOdds: Math.round(avgOdds * 100) / 100,
    })
  } catch (error) {
    console.error('Failed to fetch stats:', error)
    return NextResponse.json(
      { error: 'Failed to fetch stats' },
      { status: 500 }
    )
  }
}
