import { NextRequest, NextResponse } from 'next/server'

const SYSTEM_PROMPT =
  'You are a table tennis betting analyst assistant. Help users understand matches, odds, predictions, and betting strategy. Be concise and data-driven.'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { message, context } = body

    if (!message) {
      return NextResponse.json({ error: 'message is required' }, { status: 400 })
    }

    const ZAI = (await import('z-ai-web-dev-sdk')).default
    const zai = await ZAI.create()

    const messages: { role: string; content: string }[] = [
      { role: 'assistant', content: SYSTEM_PROMPT },
    ]

    if (context) {
      messages.push({
        role: 'user',
        content: `Context: ${context}`,
      })
    }

    messages.push({
      role: 'user',
      content: message,
    })

    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: 'disabled' },
    })

    const response = completion.choices?.[0]?.message?.content

    if (!response) {
      return NextResponse.json(
        { error: 'No response from AI' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      response,
      model: completion.model || 'unknown',
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error('Failed to process chat:', error)
    return NextResponse.json(
      { error: 'Failed to process chat' },
      { status: 500 }
    )
  }
}
