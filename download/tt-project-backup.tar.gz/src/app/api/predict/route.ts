import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const DEFAULT_MODELS = ['gpt-4o-mini', 'claude-3-5-sonnet', 'gemini-2.0-flash']

const SYSTEM_PROMPT =
  'You are a table tennis prediction expert. Analyze the match and predict the winner. Return JSON: { predictedWinner: "player1"|"player2", confidence: 0.0-1.0, analysis: "string" }'

async function getAIPrediction(
  match: {
    player1: string
    player2: string
    league: string
    status: string
    score1: number
    score2: number
    odds: { source: string; odds1: number; odds2: number }[]
  },
  model: string
): Promise<{
  predictedWinner: string
  confidence: number
  analysis: string
}> {
  try {
    const ZAI = (await import('z-ai-web-dev-sdk')).default
    const zai = await ZAI.create()

    const oddsInfo = match.odds
      .map((o) => `${o.source}: ${match.player1} @ ${o.odds1}, ${match.player2} @ ${o.odds2}`)
      .join('; ')

    const userMessage = `Match: ${match.player1} vs ${match.player2}
League: ${match.league || 'Unknown'}
Status: ${match.status}
Score: ${match.score1}-${match.score2}
Odds: ${oddsInfo || 'No odds available'}

Predict the winner. Return ONLY valid JSON.`

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: SYSTEM_PROMPT },
        { role: 'user', content: userMessage },
      ],
      thinking: { type: 'disabled' },
    })

    const content = completion.choices?.[0]?.message?.content
    if (!content) throw new Error('Empty response from AI')

    // Extract JSON from the response
    const jsonMatch = content.match(/\{[\s\S]*\}/)
    if (!jsonMatch) throw new Error('No JSON found in AI response')

    const parsed = JSON.parse(jsonMatch[0])
    return {
      predictedWinner: parsed.predictedWinner === 'player1' || parsed.predictedWinner === 'player2'
        ? parsed.predictedWinner
        : 'player1',
      confidence: Math.min(1, Math.max(0, parseFloat(parsed.confidence) || 0.5)),
      analysis: parsed.analysis || 'AI prediction generated.',
    }
  } catch {
    // Fallback: generate prediction based on odds analysis
    return generateOddsBasedPrediction(match)
  }
}

function generateOddsBasedPrediction(match: {
  player1: string
  player2: string
  odds: { source: string; odds1: number; odds2: number }[]
}): {
  predictedWinner: string
  confidence: number
  analysis: string
} {
  const odds = match.odds
  if (odds.length === 0) {
    // No odds — random with slight preference
    const isPlayer1 = Math.random() > 0.5
    return {
      predictedWinner: isPlayer1 ? 'player1' : 'player2',
      confidence: 0.5 + Math.random() * 0.15,
      analysis: `No odds data available. Based on basic analysis, ${isPlayer1 ? match.player1 : match.player2} has a slight edge.`,
    }
  }

  // Calculate implied probabilities from odds
  let totalImplied1 = 0
  let totalImplied2 = 0
  for (const o of odds) {
    totalImplied1 += 1 / o.odds1
    totalImplied2 += 1 / o.odds2
  }
  const avgImplied1 = totalImplied1 / odds.length
  const avgImplied2 = totalImplied2 / odds.length

  // Normalize
  const total = avgImplied1 + avgImplied2
  const prob1 = avgImplied1 / total
  const prob2 = avgImplied2 / total

  const predictedWinner = prob1 >= prob2 ? 'player1' : 'player2'
  const confidence = Math.max(prob1, prob2)

  const winner = predictedWinner === 'player1' ? match.player1 : match.player2
  const loser = predictedWinner === 'player1' ? match.player2 : match.player1

  const sources = odds.map((o) => o.source).join(', ')
  const analysis = `Odds-based analysis across ${sources}: ${match.player1} implied probability ${(prob1 * 100).toFixed(1)}%, ${match.player2} implied probability ${(prob2 * 100).toFixed(1)}%. ${winner} is favored with ${((confidence) * 100).toFixed(1)}% confidence.`

  return { predictedWinner, confidence, analysis }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { matchId, models } = body

    if (!matchId) {
      return NextResponse.json({ error: 'matchId is required' }, { status: 400 })
    }

    const match = await db.match.findUnique({
      where: { id: matchId },
      include: { odds: true },
    })

    if (!match) {
      return NextResponse.json({ error: 'Match not found' }, { status: 404 })
    }

    const modelsToUse = models && models.length > 0 ? models : DEFAULT_MODELS
    const predictions: {
      model: string
      predictedWinner: string
      confidence: number
      analysis: string
    }[] = []

    for (const model of modelsToUse) {
      const prediction = await getAIPrediction(match, model)
      predictions.push({ model, ...prediction })
    }

    // Store predictions in DB
    const storedPredictions = []
    for (const pred of predictions) {
      const stored = await db.prediction.create({
        data: {
          matchId,
          predictedWinner: pred.predictedWinner,
          confidence: pred.confidence,
          aiModel: pred.model,
          analysis: pred.analysis,
        },
      })
      storedPredictions.push(stored)
    }

    return NextResponse.json({
      matchId,
      predictions: storedPredictions,
    })
  } catch (error) {
    console.error('Failed to generate prediction:', error)
    return NextResponse.json(
      { error: 'Failed to generate prediction' },
      { status: 500 }
    )
  }
}
