import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = parseInt(searchParams.get('limit') || '200')
    const offset = parseInt(searchParams.get('offset') || '0')
    const platform = searchParams.get('platform')
    const activeOnly = searchParams.get('active') !== 'false'

    const where: Record<string, unknown> = {}
    if (platform) where.platform = platform
    if (activeOnly) where.isActive = true

    const [predictors, total] = await Promise.all([
      db.predictor.findMany({
        where,
        orderBy: { qualityScore: 'desc' },
        take: limit,
        skip: offset,
      }),
      db.predictor.count({ where }),
    ])

    return NextResponse.json({
      predictors,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + predictors.length < total,
      },
    })
  } catch (error) {
    console.error('Failed to fetch predictors:', error)
    return NextResponse.json(
      { error: 'Failed to fetch predictors' },
      { status: 500 }
    )
  }
}
