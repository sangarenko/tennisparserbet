'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Sparkles, BarChart3, Bot, Wallet, Radio, Trophy,
  Activity, Zap, TrendingUp, Clock, RefreshCw,
  Send, MessageSquare, Search, Filter, CheckCircle,
  AlertTriangle, Plus, ArrowUpRight, ArrowDownRight,
  Minus, CheckCircle2, XCircle, Shield, Star,
  ChevronDown, Eye, Trash2, CircleDot, Users,
  Dices, Target, Timer, Info
} from 'lucide-react'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Progress } from '@/components/ui/progress'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { Skeleton } from '@/components/ui/skeleton'
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, Legend,
} from 'recharts'
import { useAppStore, type Match, type Prediction, type Bet, type CollectionLog } from '@/hooks/use-store'
import { ConfidenceMeter } from '@/components/tt/confidence-meter'
import { MatchCard } from '@/components/tt/match-card'
import { StatsCard } from '@/components/tt/stats-card'
import { EmptyState } from '@/components/tt/empty-state'
import { LoadingSkeleton } from '@/components/tt/loading-skeleton'

// ─── Data Fetcher ─────────────────────────────────────────────────────────────
function useFetchOnMount() {
  const store = useAppStore()

  const fetchMatches = useCallback(async () => {
    store.setLoading('matches', true)
    try {
      const res = await fetch('/api/matches')
      if (res.ok) {
        const data = await res.json()
        store.setMatches(Array.isArray(data) ? data : data.matches || [])
      }
    } catch { /* noop */ }
    finally { store.setLoading('matches', false) }
  }, [store])

  const fetchBets = useCallback(async () => {
    store.setLoading('bets', true)
    try {
      const res = await fetch('/api/bets')
      if (res.ok) {
        const data = await res.json()
        store.setBets(Array.isArray(data) ? data : data.bets || [])
      }
    } catch { /* noop */ }
    finally { store.setLoading('bets', false) }
  }, [store])

  const fetchStats = useCallback(async () => {
    store.setLoading('stats', true)
    try {
      const res = await fetch('/api/stats')
      if (res.ok) {
        const data = await res.json()
        store.setStats(data)
      }
    } catch { /* noop */ }
    finally { store.setLoading('stats', false) }
  }, [store])

  const fetchPlayers = useCallback(async () => {
    try {
      const res = await fetch('/api/players')
      if (res.ok) {
        const data = await res.json()
        store.setPlayers(Array.isArray(data) ? data : data.players || [])
      }
    } catch { /* noop */ }
  }, [store])

  const fetchPredictors = useCallback(async () => {
    store.setLoading('predictors', true)
    try {
      const res = await fetch('/api/predictors')
      if (res.ok) {
        const data = await res.json()
        store.setPredictors(Array.isArray(data) ? data : data.predictors || [])
      }
    } catch { /* noop */ }
    finally { store.setLoading('predictors', false) }
  }, [store])

  const fetchCollectionLogs = useCallback(async () => {
    try {
      const res = await fetch('/api/sources')
      if (res.ok) {
        const data = await res.json()
        store.setCollectionLogs(Array.isArray(data) ? data : data.logs || [])
      }
    } catch { /* noop */ }
  }, [store])

  useEffect(() => { fetchMatches() }, [fetchMatches])
  useEffect(() => { fetchBets() }, [fetchBets])
  useEffect(() => { fetchStats() }, [fetchStats])
  useEffect(() => { fetchPlayers() }, [fetchPlayers])
  useEffect(() => { fetchPredictors() }, [fetchPredictors])
  useEffect(() => { fetchCollectionLogs() }, [fetchCollectionLogs])

  return { fetchMatches, fetchBets, fetchStats, fetchPlayers, fetchPredictors, fetchCollectionLogs }
}

// ─── Clock Hook ───────────────────────────────────────────────────────────────
function useClock() {
  const [time, setTime] = useState(new Date())
  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(interval)
  }, [])
  return time
}

// ─── Quality Badge ────────────────────────────────────────────────────────────
function getQualityBadge(score: number) {
  if (score >= 85) return { grade: 'S', color: '#00ff88', bg: 'rgba(0,255,136,0.15)' }
  if (score >= 65) return { grade: 'A', color: '#00d4ff', bg: 'rgba(0,212,255,0.15)' }
  if (score >= 45) return { grade: 'B', color: '#a855f7', bg: 'rgba(168,85,247,0.15)' }
  if (score >= 30) return { grade: 'C', color: '#f59e0b', bg: 'rgba(245,158,11,0.15)' }
  return { grade: 'D', color: '#ef4444', bg: 'rgba(239,68,68,0.15)' }
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────
export default function Page() {
  const store = useAppStore()
  const { fetchMatches, fetchBets, fetchStats, fetchCollectionLogs } = useFetchOnMount()
  const clock = useClock()

  // Chat state
  const [chatInput, setChatInput] = useState('')
  const [isChatLoading, setIsChatLoading] = useState(false)
  const chatEndRef = useRef<HTMLDivElement>(null)

  // Bet dialog state
  const [betDialogOpen, setBetDialogOpen] = useState(false)
  const [bankrollDialogOpen, setBankrollDialogOpen] = useState(false)
  const [bankrollInput, setBankrollInput] = useState('1000')
  const [betMatchId, setBetMatchId] = useState('')
  const [betWinner, setBetWinner] = useState('')
  const [betOdds, setBetOdds] = useState('')
  const [betStake, setBetStake] = useState('')

  // Predictors filter
  const [predictorSearch, setPredictorSearch] = useState('')
  const [predictorPlatform, setPredictorPlatform] = useState('all')
  const [predictorTier, setPredictorTier] = useState('all')
  const [predictorStats, setPredictorStats] = useState<Record<string, any> | null>(null)

  // Prediction loading state
  const [loadingPredictionId, setLoadingPredictionId] = useState<string | null>(null)

  // Stats computed
  const liveMatches = store.matches.filter(m => m.status === 'live')
  const totalPredictions = store.matches.reduce((sum, m) => sum + (m.predictions?.length || 0), 0)
  const correctPredictions = store.matches.reduce(
    (sum, m) => sum + (m.predictions?.filter(p => p.isCorrect === true).length || 0), 0
  )
  const winRate = totalPredictions > 0 ? ((correctPredictions / totalPredictions) * 100).toFixed(1) : '0.0'

  // Filter matches
  const filteredMatches = store.matches.filter(m => {
    if (store.matchFilter !== 'all' && m.status !== store.matchFilter) return false
    if (store.sourceFilter !== 'all' && m.source !== store.sourceFilter) return false
    return true
  })

  // Fetch predictor stats
  useEffect(() => {
    const fetchPredictorStats = async () => {
      try {
        const res = await fetch('/api/predictors/stats')
        if (res.ok) setPredictorStats(await res.json())
      } catch { /* noop */ }
    }
    fetchPredictorStats()
  }, [])

  // Filter predictors
  const filteredPredictors = store.predictors
    .filter(p => {
      if (predictorSearch && !p.name.toLowerCase().includes(predictorSearch.toLowerCase())) return false
      if (predictorPlatform !== 'all' && p.platform !== predictorPlatform) return false
      if (predictorTier !== 'all' && getQualityBadge(p.qualityScore).grade !== predictorTier) return false
      return true
    })
    .sort((a, b) => b.qualityScore - a.qualityScore)

  // Auto-scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [store.chatMessages])

  // ── Get AI Prediction ──────────────────────────────────────────────────
  const handleGetPrediction = async (match: Match) => {
    setLoadingPredictionId(match.id)
    try {
      const res = await fetch(`/api/matches/${match.id}/predict`, { method: 'POST' })
      if (res.ok) {
        const pred = await res.json()
        // Update the match in store with new prediction
        const updated = store.matches.map(m =>
          m.id === match.id
            ? { ...m, predictions: [...(m.predictions || []), pred] }
            : m
        )
        store.setMatches(updated)
        store.setCurrentPrediction(pred)
      }
    } catch { /* noop */ }
    finally { setLoadingPredictionId(null) }
  }

  // ── Send Chat Message ─────────────────────────────────────────────────
  const handleSendChat = async (message?: string) => {
    const text = message || chatInput.trim()
    if (!text) return

    const userMsg = {
      id: crypto.randomUUID(),
      role: 'user' as const,
      content: text,
      timestamp: new Date().toISOString(),
    }
    store.addChatMessage(userMsg)
    setChatInput('')
    setIsChatLoading(true)

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history: store.chatMessages }),
      })
      if (res.ok) {
        const data = await res.json()
        store.addChatMessage({
          id: crypto.randomUUID(),
          role: 'assistant',
          content: data.message || data.content || data.reply || 'Sorry, I could not process your request.',
          timestamp: new Date().toISOString(),
        })
      }
    } catch {
      store.addChatMessage({
        id: crypto.randomUUID(),
        role: 'assistant',
        content: 'Connection error. Please try again.',
        timestamp: new Date().toISOString(),
      })
    } finally {
      setIsChatLoading(false)
    }
  }

  // ── Place Bet ─────────────────────────────────────────────────────────
  const handlePlaceBet = async () => {
    if (!betMatchId || !betWinner || !betOdds || !betStake) return
    try {
      const res = await fetch('/api/bets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          matchId: betMatchId,
          predictedWinner: betWinner,
          odds: parseFloat(betOdds),
          stake: parseFloat(betStake),
        }),
      })
      if (res.ok) {
        fetchBets()
        fetchStats()
        setBetDialogOpen(false)
        setBetMatchId('')
        setBetWinner('')
        setBetOdds('')
        setBetStake('')
      }
    } catch { /* noop */ }
  }

  // ── Set Bankroll ──────────────────────────────────────────────────────
  const handleSetBankroll = async () => {
    const amount = parseFloat(bankrollInput)
    if (isNaN(amount) || amount <= 0) return
    store.setBankroll(amount)
    setBankrollDialogOpen(false)
  }

  // ── Sync Sources ──────────────────────────────────────────────────────
  const handleSyncSources = async () => {
    store.setLoading('sync', true)
    try {
      await fetch('/api/sources/sync', { method: 'POST' })
      fetchMatches()
      fetchCollectionLogs()
    } catch { /* noop */ }
    finally { store.setLoading('sync', false) }
  }

  // ── Verify/Prune Predictors ───────────────────────────────────────────
  const handleVerifyAll = async () => {
    try {
      await fetch('/api/predictors/verify', { method: 'POST' })
      useAppStore.getState().setPredictors(
        useAppStore.getState().predictors.map(p => ({ ...p, verified: true }))
      )
    } catch { /* noop */ }
  }

  const handlePruneLowQuality = async () => {
    try {
      await fetch('/api/predictors/prune', { method: 'POST' })
      useAppStore.getState().setPredictors(
        useAppStore.getState().predictors.filter(p => p.qualityScore >= 40)
      )
    } catch { /* noop */ }
  }

  // ── Bet result helper ─────────────────────────────────────────────────
  const betResultBadge = (result: string | null) => {
    if (result === 'win') return <Badge className="bg-neon-green/15 text-neon-green border border-neon-green/20">WIN</Badge>
    if (result === 'loss') return <Badge className="bg-neon-red/15 text-neon-red border border-neon-red/20">LOSS</Badge>
    if (result === 'void') return <Badge className="bg-white/5 text-muted-foreground border border-white/8">VOID</Badge>
    return <Badge className="bg-neon-orange/15 text-neon-orange border border-neon-orange/20">PENDING</Badge>
  }

  // ── Analytics chart data ──────────────────────────────────────────────
  const analyticsChartData = [
    { name: 'Week 1', winRate: 62, predictions: 15 },
    { name: 'Week 2', winRate: 58, predictions: 22 },
    { name: 'Week 3', winRate: 71, predictions: 18 },
    { name: 'Week 4', winRate: 65, predictions: 25 },
    { name: 'Week 5', winRate: 73, predictions: 20 },
    { name: 'Week 6', winRate: 68, predictions: 28 },
    { name: 'Week 7', winRate: 75, predictions: 30 },
  ]

  const confidenceData = [
    { range: '0-20', count: 5 },
    { range: '21-40', count: 12 },
    { range: '41-60', count: 25 },
    { range: '61-80', count: 35 },
    { range: '81-100', count: 18 },
  ]

  const sourceData = [
    { name: 'BetBoom', value: 45, color: '#fb923c' },
    { name: 'Fonbet', value: 38, color: '#00d4ff' },
    { name: 'Overlap', value: 17, color: '#a855f7' },
  ]

  const roiData = [
    { name: 'Jan', roi: 2.5 },
    { name: 'Feb', roi: -1.2 },
    { name: 'Mar', roi: 5.8 },
    { name: 'Apr', roi: 8.3 },
    { name: 'May', roi: 3.1 },
    { name: 'Jun', roi: 12.5 },
    { name: 'Jul', roi: 15.2 },
  ]

  const bankrollChartData = [
    { name: 'W1', value: store.bankroll || 1000 },
    { name: 'W2', value: (store.bankroll || 1000) * 1.03 },
    { name: 'W3', value: (store.bankroll || 1000) * 0.98 },
    { name: 'W4', value: (store.bankroll || 1000) * 1.08 },
    { name: 'W5', value: (store.bankroll || 1000) * 1.15 },
    { name: 'W6', value: (store.bankroll || 1000) * 1.12 },
  ]

  // ─── RENDER ──────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Background Blobs */}
      <div className="bg-blob w-[400px] h-[400px] bg-neon-green top-[-100px] left-[-100px]" />
      <div className="bg-blob w-[350px] h-[350px] bg-neon-purple bottom-[-80px] right-[-80px]" />
      <div className="bg-blob w-[300px] h-[300px] bg-neon-blue top-[40%] right-[10%]" />

      {/* ── HEADER ────────────────────────────────────────────────────────── */}
      <header className="relative z-10 border-b border-white/[0.06] backdrop-blur-xl bg-background/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold gradient-text tracking-tight">
                🏓 TT Predict Pro
              </h1>
              <p className="text-xs sm:text-sm text-muted-foreground mt-0.5">
                Table Tennis Analytics &amp; AI Predictions
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="size-3" />
              <span className="font-mono">
                {clock.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
              <span className="hidden sm:inline">•</span>
              <span className="hidden sm:inline">
                {clock.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
              </span>
            </div>
          </div>

          {/* Quick Stats Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
            <StatsCard
              icon={Dices}
              label="Total Matches"
              value={store.matches.length}
              color="#00d4ff"
              index={0}
            />
            <StatsCard
              icon={CircleDot}
              label="Live Now"
              value={liveMatches.length}
              color="#00ff88"
              index={1}
            />
            <StatsCard
              icon={Sparkles}
              label="AI Predictions"
              value={totalPredictions}
              color="#a855f7"
              index={2}
            />
            <StatsCard
              icon={Target}
              label="Win Rate"
              value={`${winRate}%`}
              color="#f472b6"
              change={parseFloat(winRate) > 50 ? parseFloat(winRate) - 50 : 0}
              index={3}
            />
          </div>
        </div>
      </header>

      {/* ── MAIN CONTENT ──────────────────────────────────────────────────── */}
      <main className="flex-1 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
          <Tabs value={store.activeTab} onValueChange={store.setActiveTab}>
            {/* Tab Navigation */}
            <TabsList className="w-full flex-wrap h-auto p-1 gap-1 mb-6 bg-white/[0.03] backdrop-blur-lg border border-white/[0.06] rounded-xl">
              {[
                { value: 'predictions', icon: Sparkles, label: 'Predictions' },
                { value: 'analytics', icon: BarChart3, label: 'Analytics' },
                { value: 'assistant', icon: Bot, label: 'AI Assistant' },
                { value: 'bankroll', icon: Wallet, label: 'Bankroll' },
                { value: 'sources', icon: Radio, label: 'Sources' },
                { value: 'predictors', icon: Trophy, label: 'Predictors' },
              ].map(tab => (
                <TabsTrigger
                  key={tab.value}
                  value={tab.value}
                  className="flex-1 min-w-[100px] data-[state=active]:bg-white/[0.08] data-[state=active]:text-neon-green gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all"
                >
                  <tab.icon className="size-3.5" />
                  <span className="hidden xs:inline">{tab.label}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            {/* ═══════════════════════════════════════════════════════════════ */}
            {/* TAB 1: PREDICTIONS                                          */}
            {/* ═══════════════════════════════════════════════════════════════ */}
            <TabsContent value="predictions">
              <AnimatePresence mode="wait">
                <motion.div
                  key="predictions"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Filter Bar */}
                  <div className="flex flex-wrap items-center gap-3 mb-4">
                    <div className="flex items-center gap-2">
                      <Filter className="size-4 text-muted-foreground" />
                      <Select value={store.matchFilter} onValueChange={(v) => store.setMatchFilter(v as typeof store.matchFilter)}>
                        <SelectTrigger className="w-[130px] h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Status</SelectItem>
                          <SelectItem value="upcoming">Upcoming</SelectItem>
                          <SelectItem value="live">🔴 Live</SelectItem>
                          <SelectItem value="finished">Finished</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Select value={store.sourceFilter} onValueChange={(v) => store.setSourceFilter(v as typeof store.sourceFilter)}>
                      <SelectTrigger className="w-[120px] h-8 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Sources</SelectItem>
                        <SelectItem value="betboom">BetBoom</SelectItem>
                        <SelectItem value="fonbet">Fonbet</SelectItem>
                      </SelectContent>
                    </Select>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="ml-auto text-xs"
                      onClick={() => fetchMatches()}
                    >
                      <RefreshCw className="size-3" />
                      Refresh
                    </Button>
                  </div>

                  {/* Match Grid */}
                  {store.isLoading.matches ? (
                    <LoadingSkeleton />
                  ) : filteredMatches.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {filteredMatches.map((match, i) => (
                        <MatchCard
                          key={match.id}
                          match={match}
                          index={i}
                          prediction={match.predictions?.[match.predictions.length - 1] || null}
                          isLoadingPrediction={loadingPredictionId === match.id}
                          onGetPrediction={handleGetPrediction}
                        />
                      ))}
                    </div>
                  ) : (
                    <EmptyState
                      icon={Sparkles}
                      title="No Matches Found"
                      description="No matches match your current filters. Try adjusting the status or source filter, or wait for new matches to be collected."
                      action={{ label: 'Refresh Matches', onClick: () => fetchMatches() }}
                    />
                  )}
                </motion.div>
              </AnimatePresence>
            </TabsContent>

            {/* ═══════════════════════════════════════════════════════════════ */}
            {/* TAB 2: ANALYTICS                                            */}
            {/* ═══════════════════════════════════════════════════════════════ */}
            <TabsContent value="analytics">
              <AnimatePresence mode="wait">
                <motion.div
                  key="analytics"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  {/* Summary Cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <StatsCard icon={Dices} label="Total Matches" value={store.matches.length || 0} color="#00d4ff" index={0} />
                    <StatsCard icon={Sparkles} label="Predictions Made" value={totalPredictions || 0} color="#a855f7" index={1} />
                    <StatsCard icon={Target} label="Accuracy" value={`${winRate}%`} color="#00ff88" index={2} />
                    <StatsCard icon={Activity} label="Avg Confidence" value={`${store.stats?.avgConfidence?.toFixed(0) || '0'}%`} color="#f472b6" index={3} />
                  </div>

                  {/* Charts Grid */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {/* Win Rate Over Time */}
                    <div className="glass-card rounded-xl p-4 sm:p-6">
                      <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                        <TrendingUp className="size-4 text-neon-green" />
                        Win Rate Over Time
                      </h3>
                      <div className="h-[220px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={analyticsChartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                            <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.4)' }} />
                            <YAxis tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.4)' }} domain={[0, 100]} />
                            <RechartsTooltip
                              contentStyle={{ background: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 12 }}
                              labelStyle={{ color: 'rgba(255,255,255,0.7)' }}
                            />
                            <Line type="monotone" dataKey="winRate" stroke="#00ff88" strokeWidth={2} dot={{ fill: '#00ff88', r: 4 }} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Confidence Distribution */}
                    <div className="glass-card rounded-xl p-4 sm:p-6">
                      <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                        <BarChart3 className="size-4 text-neon-purple" />
                        Confidence Distribution
                      </h3>
                      <div className="h-[220px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={confidenceData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                            <XAxis dataKey="range" tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.4)' }} />
                            <YAxis tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.4)' }} />
                            <RechartsTooltip
                              contentStyle={{ background: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 12 }}
                            />
                            <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                              {confidenceData.map((_, i) => (
                                <Cell key={i} fill={['#ef4444', '#f59e0b', '#f59e0b', '#00ff88', '#00ff88'][i]} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Source Comparison Pie */}
                    <div className="glass-card rounded-xl p-4 sm:p-6">
                      <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                        <PieChart className="size-4 text-neon-blue" />
                        Source Comparison
                      </h3>
                      <div className="h-[220px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={sourceData}
                              cx="50%"
                              cy="50%"
                              innerRadius={50}
                              outerRadius={80}
                              dataKey="value"
                              paddingAngle={3}
                            >
                              {sourceData.map((entry, i) => (
                                <Cell key={i} fill={entry.color} />
                              ))}
                            </Pie>
                            <RechartsTooltip
                              contentStyle={{ background: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 12 }}
                            />
                            <Legend
                              iconType="circle"
                              wrapperStyle={{ fontSize: 11, color: 'rgba(255,255,255,0.6)' }}
                            />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* ROI Trend */}
                    <div className="glass-card rounded-xl p-4 sm:p-6">
                      <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                        <Activity className="size-4 text-neon-orange" />
                        ROI Trend
                      </h3>
                      <div className="h-[220px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={roiData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                            <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.4)' }} />
                            <YAxis tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.4)' }} />
                            <RechartsTooltip
                              contentStyle={{ background: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 12 }}
                            />
                            <defs>
                              <linearGradient id="roiGradient" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#00ff88" stopOpacity={0.3} />
                                <stop offset="95%" stopColor="#00ff88" stopOpacity={0} />
                              </linearGradient>
                            </defs>
                            <Area type="monotone" dataKey="roi" stroke="#00ff88" fill="url(#roiGradient)" strokeWidth={2} />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>

                  {/* Player Leaderboard */}
                  <div className="glass-card rounded-xl p-4 sm:p-6">
                    <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                      <Users className="size-4 text-neon-blue" />
                      Player Leaderboard
                    </h3>
                    {store.players.length > 0 ? (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="border-white/[0.06] hover:bg-transparent">
                              <TableHead className="text-xs">#</TableHead>
                              <TableHead className="text-xs">Player</TableHead>
                              <TableHead className="text-xs text-right">W/L</TableHead>
                              <TableHead className="text-xs text-right">Win Rate</TableHead>
                              <TableHead className="text-xs text-right">Avg Odds</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {store.players.slice(0, 10).map((player, i) => (
                              <TableRow key={player.id} className="border-white/[0.04]">
                                <TableCell className="text-xs text-muted-foreground">{i + 1}</TableCell>
                                <TableCell className="text-xs font-semibold">
                                  {player.country && <span className="mr-1">{player.country}</span>}
                                  {player.name}
                                </TableCell>
                                <TableCell className="text-xs text-right">
                                  <span className="text-neon-green">{player.wins}</span>
                                  <span className="text-muted-foreground">/{player.losses}</span>
                                </TableCell>
                                <TableCell className="text-xs text-right">
                                  <span className={player.winRate >= 60 ? 'text-neon-green font-semibold' : 'text-muted-foreground'}>
                                    {player.winRate.toFixed(1)}%
                                  </span>
                                </TableCell>
                                <TableCell className="text-xs text-right text-muted-foreground">
                                  {player.avgOdds?.toFixed(2) || '-'}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <EmptyState
                        icon={Users}
                        title="No Player Data Yet"
                        description="Player statistics will appear here once matches are collected and analyzed."
                      />
                    )}
                  </div>
                </motion.div>
              </AnimatePresence>
            </TabsContent>

            {/* ═══════════════════════════════════════════════════════════════ */}
            {/* TAB 3: AI ASSISTANT                                          */}
            {/* ═══════════════════════════════════════════════════════════════ */}
            <TabsContent value="assistant">
              <AnimatePresence mode="wait">
                <motion.div
                  key="assistant"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                  className="glass-card rounded-xl flex flex-col h-[calc(100vh-320px)] min-h-[500px]"
                >
                  {/* Chat Header */}
                  <div className="p-4 border-b border-white/[0.06] flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-neon-purple/15 flex items-center justify-center">
                      <Bot className="size-4 text-neon-purple" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold">TT Predict AI</div>
                      <div className="text-[10px] text-muted-foreground">Powered by advanced analytics</div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="ml-auto text-xs text-muted-foreground"
                      onClick={() => store.clearChat()}
                    >
                      Clear Chat
                    </Button>
                  </div>

                  {/* Quick Actions */}
                  <div className="px-4 py-2 border-b border-white/[0.06] flex flex-wrap gap-2">
                    {[
                      { icon: Dices, label: 'Analyze upcoming matches', msg: 'Analyze the upcoming matches and give me predictions' },
                      { icon: Star, label: 'Best bets today', msg: 'What are the best bets today based on current odds?' },
                      { icon: Wallet, label: 'Bankroll advice', msg: 'Give me bankroll management advice for table tennis betting' },
                    ].map(action => (
                      <button
                        key={action.label}
                        onClick={() => handleSendChat(action.msg)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-[11px] text-muted-foreground hover:text-foreground transition-all border border-white/[0.06]"
                      >
                        <action.icon className="size-3" />
                        {action.label}
                      </button>
                    ))}
                  </div>

                  {/* Messages */}
                  <ScrollArea className="flex-1 p-4">
                    {store.chatMessages.length === 0 ? (
                      <EmptyState
                        icon={MessageSquare}
                        title="Start a Conversation"
                        description="Ask me about upcoming matches, predictions, betting strategies, or any table tennis analytics questions."
                      />
                    ) : (
                      <div className="space-y-4">
                        {store.chatMessages.map((msg) => (
                          <motion.div
                            key={msg.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                          >
                            <div
                              className={`max-w-[80%] sm:max-w-[70%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                                msg.role === 'user'
                                  ? 'bg-neon-green/10 text-foreground border border-neon-green/20 rounded-br-md'
                                  : 'bg-white/[0.04] text-foreground border border-white/[0.06] rounded-bl-md'
                              }`}
                            >
                              {msg.content}
                            </div>
                          </motion.div>
                        ))}
                        {isChatLoading && (
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="flex justify-start"
                          >
                            <div className="bg-white/[0.04] border border-white/[0.06] rounded-2xl rounded-bl-md px-4 py-3">
                              <div className="flex gap-1">
                                <div className="w-2 h-2 rounded-full bg-neon-purple animate-bounce [animation-delay:0ms]" />
                                <div className="w-2 h-2 rounded-full bg-neon-purple animate-bounce [animation-delay:150ms]" />
                                <div className="w-2 h-2 rounded-full bg-neon-purple animate-bounce [animation-delay:300ms]" />
                              </div>
                            </div>
                          </motion.div>
                        )}
                        <div ref={chatEndRef} />
                      </div>
                    )}
                  </ScrollArea>

                  {/* Chat Input */}
                  <div className="p-4 border-t border-white/[0.06]">
                    <form
                      onSubmit={(e) => { e.preventDefault(); handleSendChat() }}
                      className="flex items-center gap-2"
                    >
                      <Input
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        placeholder="Ask about predictions, matches, strategies..."
                        className="flex-1 h-10 bg-white/[0.04] border-white/[0.08] text-sm focus-visible:ring-neon-purple/30 focus-visible:border-neon-purple/30"
                        disabled={isChatLoading}
                      />
                      <Button
                        type="submit"
                        size="icon"
                        className="h-10 w-10 bg-neon-purple/20 text-neon-purple hover:bg-neon-purple/30 border-0"
                        disabled={!chatInput.trim() || isChatLoading}
                      >
                        <Send className="size-4" />
                      </Button>
                    </form>
                  </div>
                </motion.div>
              </AnimatePresence>
            </TabsContent>

            {/* ═══════════════════════════════════════════════════════════════ */}
            {/* TAB 4: BANKROLL                                             */}
            {/* ═══════════════════════════════════════════════════════════════ */}
            <TabsContent value="bankroll">
              <AnimatePresence mode="wait">
                <motion.div
                  key="bankroll"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  {/* Bankroll Overview */}
                  <div className="glass-card rounded-xl p-6 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-neon-green/5 rounded-full blur-3xl" />
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 relative">
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">Current Bankroll</div>
                        <div className="text-4xl font-bold gradient-text">
                          ${(store.bankroll || 1000).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                          <span>Total Staked: <span className="text-foreground font-medium">${store.stats?.totalStaked?.toLocaleString() || '0.00'}</span></span>
                          <span>•</span>
                          <span>Profit: <span className={(store.stats?.profit ?? 0) >= 0 ? 'text-neon-green font-medium' : 'text-neon-red font-medium'}>${(store.stats?.profit ?? 0).toLocaleString()}</span></span>
                          <span>•</span>
                          <span>ROI: <span className={(store.stats?.roi ?? 0) >= 0 ? 'text-neon-green font-medium' : 'text-neon-red font-medium'}>{(store.stats?.roi ?? 0).toFixed(1)}%</span></span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Dialog open={bankrollDialogOpen} onOpenChange={setBankrollDialogOpen}>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" className="text-xs">
                              <Wallet className="size-3" />
                              Set Bankroll
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="glass-card bg-background border-white/[0.08]">
                            <DialogHeader>
                              <DialogTitle>Set Initial Bankroll</DialogTitle>
                              <DialogDescription>Enter your starting bankroll amount</DialogDescription>
                            </DialogHeader>
                            <Input
                              type="number"
                              placeholder="1000"
                              value={bankrollInput}
                              onChange={(e) => setBankrollInput(e.target.value)}
                              className="h-10"
                            />
                            <DialogFooter>
                              <Button size="sm" onClick={handleSetBankroll} className="bg-neon-green/20 text-neon-green hover:bg-neon-green/30">
                                Confirm
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                        <Dialog open={betDialogOpen} onOpenChange={setBetDialogOpen}>
                          <DialogTrigger asChild>
                            <Button size="sm" className="text-xs bg-neon-purple/20 text-neon-purple hover:bg-neon-purple/30 border-0">
                              <Plus className="size-3" />
                              Place Bet
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="glass-card bg-background border-white/[0.08]">
                            <DialogHeader>
                              <DialogTitle>Place a Bet</DialogTitle>
                              <DialogDescription>Select a match and your prediction</DialogDescription>
                            </DialogHeader>
                            <div className="space-y-3">
                              <div>
                                <label className="text-xs text-muted-foreground mb-1 block">Match</label>
                                <Select value={betMatchId} onValueChange={setBetMatchId}>
                                  <SelectTrigger className="w-full h-9 text-xs">
                                    <SelectValue placeholder="Select a match" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {store.matches.filter(m => m.status !== 'finished').map(m => (
                                      <SelectItem key={m.id} value={m.id} className="text-xs">
                                        {m.player1} vs {m.player2} ({m.source})
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <label className="text-xs text-muted-foreground mb-1 block">Predicted Winner</label>
                                <Select value={betWinner} onValueChange={setBetWinner}>
                                  <SelectTrigger className="w-full h-9 text-xs">
                                    <SelectValue placeholder="Select winner" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {betMatchId && (() => {
                                      const match = store.matches.find(m => m.id === betMatchId)
                                      if (!match) return null
                                      return (
                                        <>
                                          <SelectItem value={match.player1}>{match.player1}</SelectItem>
                                          <SelectItem value={match.player2}>{match.player2}</SelectItem>
                                        </>
                                      )
                                    })()}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="grid grid-cols-2 gap-3">
                                <div>
                                  <label className="text-xs text-muted-foreground mb-1 block">Odds</label>
                                  <Input
                                    type="number"
                                    step="0.01"
                                    placeholder="1.85"
                                    value={betOdds}
                                    onChange={(e) => setBetOdds(e.target.value)}
                                    className="h-9 text-xs"
                                  />
                                </div>
                                <div>
                                  <label className="text-xs text-muted-foreground mb-1 block">Stake ($)</label>
                                  <Input
                                    type="number"
                                    step="1"
                                    placeholder="10"
                                    value={betStake}
                                    onChange={(e) => setBetStake(e.target.value)}
                                    className="h-9 text-xs"
                                  />
                                </div>
                              </div>
                              {betOdds && betStake && (
                                <div className="text-xs text-muted-foreground bg-white/[0.03] rounded-lg p-2">
                                  Potential win: <span className="text-neon-green font-semibold">
                                    ${(parseFloat(betOdds) * parseFloat(betStake)).toFixed(2)}
                                  </span>
                                </div>
                              )}
                            </div>
                            <DialogFooter>
                              <Button size="sm" onClick={handlePlaceBet} disabled={!betMatchId || !betWinner || !betOdds || !betStake} className="bg-neon-purple/20 text-neon-purple hover:bg-neon-purple/30">
                                Place Bet
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>
                  </div>

                  {/* Bankroll Quick Stats */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <StatsCard icon={ArrowUpRight} label="Total Staked" value={`$${store.stats?.totalStaked?.toLocaleString() || '0'}`} color="#00d4ff" index={0} />
                    <StatsCard icon={(store.stats?.profit ?? 0) >= 0 ? TrendingUp : AlertTriangle} label="Total P/L" value={`$${(store.stats?.profit ?? 0).toLocaleString()}`} color={(store.stats?.profit ?? 0) >= 0 ? '#00ff88' : '#ef4444'} index={1} />
                    <StatsCard icon={Activity} label="ROI" value={`${(store.stats?.roi || 0).toFixed(1)}%`} color="#a855f7" index={2} />
                    <StatsCard icon={Zap} label="Current Streak" value={store.stats?.currentStreak || 0} color="#f472b6" index={3} />
                  </div>

                  {/* P&L Chart */}
                  <div className="glass-card rounded-xl p-4 sm:p-6">
                    <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                      <TrendingUp className="size-4 text-neon-green" />
                      Bankroll Over Time
                    </h3>
                    <div className="h-[200px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={bankrollChartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                          <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.4)' }} />
                          <YAxis tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.4)' }} />
                          <RechartsTooltip
                            contentStyle={{ background: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 12 }}
                          />
                          <defs>
                            <linearGradient id="bankrollGradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#00d4ff" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#00d4ff" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <Area type="monotone" dataKey="value" stroke="#00d4ff" fill="url(#bankrollGradient)" strokeWidth={2} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Active Bets */}
                  <div className="glass-card rounded-xl p-4 sm:p-6">
                    <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                      <Timer className="size-4 text-neon-orange" />
                      Active Bets
                    </h3>
                    {store.bets.filter(b => b.result === null).length > 0 ? (
                      <div className="space-y-2 max-h-48 overflow-y-auto">
                        {store.bets.filter(b => b.result === null).map(bet => (
                          <div key={bet.id} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.03] border border-white/[0.06]">
                            <div>
                              <div className="text-xs font-semibold">{bet.match?.player1 || 'Unknown'} vs {bet.match?.player2 || 'Unknown'}</div>
                              <div className="text-[10px] text-muted-foreground mt-0.5">
                                On: {bet.predictedWinner} • Odds: {bet.odds.toFixed(2)}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-xs font-semibold">${bet.stake.toFixed(2)}</div>
                              {betResultBadge(bet.result)}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground text-center py-4">No active bets. Place a bet to get started!</p>
                    )}
                  </div>

                  {/* Settled Bets History */}
                  <div className="glass-card rounded-xl p-4 sm:p-6">
                    <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                      <CheckCircle className="size-4 text-neon-green" />
                      Bet History
                    </h3>
                    {store.bets.filter(b => b.result !== null).length > 0 ? (
                      <div className="overflow-x-auto max-h-64 overflow-y-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="border-white/[0.06] hover:bg-transparent">
                              <TableHead className="text-xs">Match</TableHead>
                              <TableHead className="text-xs">Pick</TableHead>
                              <TableHead className="text-xs text-right">Odds</TableHead>
                              <TableHead className="text-xs text-right">Stake</TableHead>
                              <TableHead className="text-xs text-right">Payout</TableHead>
                              <TableHead className="text-xs text-right">Result</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {store.bets.filter(b => b.result !== null).slice(0, 20).map(bet => (
                              <TableRow key={bet.id} className="border-white/[0.04]">
                                <TableCell className="text-xs">
                                  {bet.match?.player1} vs {bet.match?.player2}
                                </TableCell>
                                <TableCell className="text-xs">{bet.predictedWinner}</TableCell>
                                <TableCell className="text-xs text-right">{bet.odds.toFixed(2)}</TableCell>
                                <TableCell className="text-xs text-right">${bet.stake.toFixed(2)}</TableCell>
                                <TableCell className={`text-xs text-right font-medium ${bet.payout > 0 ? 'text-neon-green' : ''}`}>
                                  ${bet.payout.toFixed(2)}
                                </TableCell>
                                <TableCell className="text-xs text-right">{betResultBadge(bet.result)}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground text-center py-4">No settled bets yet. Your bet history will appear here.</p>
                    )}
                  </div>
                </motion.div>
              </AnimatePresence>
            </TabsContent>

            {/* ═══════════════════════════════════════════════════════════════ */}
            {/* TAB 5: SOURCES                                              */}
            {/* ═══════════════════════════════════════════════════════════════ */}
            <TabsContent value="sources">
              <AnimatePresence mode="wait">
                <motion.div
                  key="sources"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  {/* Source Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* BetBoom Card */}
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0 }}
                      className="glass-card rounded-xl p-5 hover:neon-glow-green"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-neon-orange/15 flex items-center justify-center">
                            <Radio className="size-5 text-neon-orange" />
                          </div>
                          <div>
                            <div className="text-sm font-semibold">BetBoom</div>
                            <div className="text-[10px] text-muted-foreground">Primary Source</div>
                          </div>
                        </div>
                        <Badge className="bg-neon-green/15 text-neon-green border border-neon-green/20 text-[10px]">
                          <span className="w-1.5 h-1.5 rounded-full bg-neon-green pulse-live mr-1" />
                          Active
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Matches Collected</span>
                          <span className="font-semibold">{store.matches.filter(m => m.source === 'betboom').length}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Live Matches</span>
                          <span className="font-semibold">{store.matches.filter(m => m.source === 'betboom' && m.status === 'live').length}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Last Sync</span>
                          <span className="font-semibold">
                            {store.collectionLogs.filter(l => l.source === 'betboom')[0]?.createdAt
                              ? new Date(store.collectionLogs.filter(l => l.source === 'betboom')[0].createdAt).toLocaleTimeString()
                              : 'Never'}
                          </span>
                        </div>
                      </div>
                    </motion.div>

                    {/* Fonbet Card */}
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 }}
                      className="glass-card rounded-xl p-5 hover:neon-glow-blue"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-neon-blue/15 flex items-center justify-center">
                            <Radio className="size-5 text-neon-blue" />
                          </div>
                          <div>
                            <div className="text-sm font-semibold">Fonbet</div>
                            <div className="text-[10px] text-muted-foreground">Secondary Source</div>
                          </div>
                        </div>
                        <Badge className="bg-neon-green/15 text-neon-green border border-neon-green/20 text-[10px]">
                          <span className="w-1.5 h-1.5 rounded-full bg-neon-green pulse-live mr-1" />
                          Active
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Matches Collected</span>
                          <span className="font-semibold">{store.matches.filter(m => m.source === 'fonbet').length}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Live Matches</span>
                          <span className="font-semibold">{store.matches.filter(m => m.source === 'fonbet' && m.status === 'live').length}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Last Sync</span>
                          <span className="font-semibold">
                            {store.collectionLogs.filter(l => l.source === 'fonbet')[0]?.createdAt
                              ? new Date(store.collectionLogs.filter(l => l.source === 'fonbet')[0].createdAt).toLocaleTimeString()
                              : 'Never'}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  </div>

                  {/* Comparison Table */}
                  <div className="glass-card rounded-xl p-4 sm:p-6">
                    <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                      <BarChart3 className="size-4 text-neon-purple" />
                      Source Comparison
                    </h3>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-white/[0.06] hover:bg-transparent">
                            <TableHead className="text-xs">Metric</TableHead>
                            <TableHead className="text-xs text-right text-neon-orange">BetBoom</TableHead>
                            <TableHead className="text-xs text-right text-neon-blue">Fonbet</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          <TableRow className="border-white/[0.04]">
                            <TableCell className="text-xs">Total Matches</TableCell>
                            <TableCell className="text-xs text-right font-semibold">{store.matches.filter(m => m.source === 'betboom').length}</TableCell>
                            <TableCell className="text-xs text-right font-semibold">{store.matches.filter(m => m.source === 'fonbet').length}</TableCell>
                          </TableRow>
                          <TableRow className="border-white/[0.04]">
                            <TableCell className="text-xs">Live Matches</TableCell>
                            <TableCell className="text-xs text-right">{store.matches.filter(m => m.source === 'betboom' && m.status === 'live').length}</TableCell>
                            <TableCell className="text-xs text-right">{store.matches.filter(m => m.source === 'fonbet' && m.status === 'live').length}</TableCell>
                          </TableRow>
                          <TableRow className="border-white/[0.04]">
                            <TableCell className="text-xs">Avg Odds</TableCell>
                            <TableCell className="text-xs text-right">
                              {(store.matches.filter(m => m.source === 'betboom' && m.odds?.length)
                                .reduce((s, m) => s + (m.odds!.reduce((a, o) => a + (o.odds1 + o.odds2) / 2, 0) / m.odds!.length), 0)
                                / Math.max(1, store.matches.filter(m => m.source === 'betboom' && m.odds?.length).length)
                              ).toFixed(2) || 'N/A'}
                            </TableCell>
                            <TableCell className="text-xs text-right">
                              {(store.matches.filter(m => m.source === 'fonbet' && m.odds?.length)
                                .reduce((s, m) => s + (m.odds!.reduce((a, o) => a + (o.odds1 + o.odds2) / 2, 0) / m.odds!.length), 0)
                                / Math.max(1, store.matches.filter(m => m.source === 'fonbet' && m.odds?.length).length)
                              ).toFixed(2) || 'N/A'}
                            </TableCell>
                          </TableRow>
                          <TableRow className="border-white/[0.04]">
                            <TableCell className="text-xs">Predictions</TableCell>
                            <TableCell className="text-xs text-right">
                              {store.matches.filter(m => m.source === 'betboom' && m.predictions?.length).length}
                            </TableCell>
                            <TableCell className="text-xs text-right">
                              {store.matches.filter(m => m.source === 'fonbet' && m.predictions?.length).length}
                            </TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </div>
                  </div>

                  {/* Collection Log */}
                  <div className="glass-card rounded-xl p-4 sm:p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-sm font-semibold flex items-center gap-2">
                        <Timer className="size-4 text-neon-blue" />
                        Collection Log
                      </h3>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-xs border-neon-green/30 text-neon-green hover:bg-neon-green/10"
                        onClick={handleSyncSources}
                        disabled={store.isLoading.sync}
                      >
                        <RefreshCw className={`size-3 ${store.isLoading.sync ? 'animate-spin' : ''}`} />
                        Sync Now
                      </Button>
                    </div>
                    {store.collectionLogs.length > 0 ? (
                      <div className="space-y-2 max-h-96 overflow-y-auto">
                        {store.collectionLogs.slice(0, 20).map((log) => (
                          <div key={log.id} className="flex items-center gap-3 p-2.5 rounded-lg bg-white/[0.02] border border-white/[0.04] text-xs">
                            <Badge className={`text-[10px] ${log.status === 'success' ? 'bg-neon-green/15 text-neon-green border border-neon-green/20' : 'bg-neon-red/15 text-neon-red border border-neon-red/20'}`}>
                              {log.status === 'success' ? '✓' : '✗'}
                            </Badge>
                            <span className={`font-medium ${log.source === 'betboom' ? 'text-neon-orange' : 'text-neon-blue'}`}>
                              {log.source}
                            </span>
                            <span className="text-muted-foreground">Found: {log.matchesFound} | New: {log.matchesNew} | Updated: {log.matchesUpdated}</span>
                            <span className="ml-auto text-muted-foreground text-[10px]">
                              {log.duration}ms
                            </span>
                            <span className="text-[10px] text-muted-foreground">
                              {new Date(log.createdAt).toLocaleTimeString()}
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <EmptyState
                        icon={Radio}
                        title="No Collection Logs"
                        description="Collection logs will appear here after the first sync operation."
                        action={{ label: 'Sync Now', onClick: handleSyncSources }}
                      />
                    )}
                  </div>
                </motion.div>
              </AnimatePresence>
            </TabsContent>

            {/* ═══════════════════════════════════════════════════════════════ */}
            {/* TAB 6: PREDICTORS                                           */}
            {/* ═══════════════════════════════════════════════════════════════ */}
            <TabsContent value="predictors">
              <AnimatePresence mode="wait">
                <motion.div
                  key="predictors"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-5"
                >
                  {/* ── 1. Summary Stats Bar ────────────────────────────────── */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0 }}
                      className="glass-card rounded-xl p-4 flex items-center gap-3"
                    >
                      <div className="w-10 h-10 rounded-lg bg-neon-blue/15 flex items-center justify-center shrink-0">
                        <Users className="size-5 text-neon-blue" />
                      </div>
                      <div>
                        <div className="text-lg font-bold">{predictorStats?.total ?? store.predictors.length}</div>
                        <div className="text-[10px] text-muted-foreground">Total Predictors</div>
                      </div>
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.05 }}
                      className="glass-card rounded-xl p-4 flex items-center gap-3"
                    >
                      <div className="w-10 h-10 rounded-lg bg-neon-green/15 flex items-center justify-center shrink-0">
                        <CheckCircle2 className="size-5 text-neon-green" />
                      </div>
                      <div>
                        <div className="text-lg font-bold text-neon-green">{predictorStats?.verified ?? 0}</div>
                        <div className="text-[10px] text-muted-foreground">Verified</div>
                      </div>
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 }}
                      className="glass-card rounded-xl p-4 flex items-center gap-3"
                    >
                      <div className="w-10 h-10 rounded-lg bg-neon-purple/15 flex items-center justify-center shrink-0">
                        <Target className="size-5 text-neon-purple" />
                      </div>
                      <div>
                        <div className="text-lg font-bold">{predictorStats?.avgWinRate ?? '0'}%</div>
                        <div className="text-[10px] text-muted-foreground">Avg Win Rate</div>
                      </div>
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.15 }}
                      className="glass-card rounded-xl p-4 flex items-center gap-3"
                    >
                      <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0" style={{ background: 'rgba(0,255,136,0.15)' }}>
                        <Star className="size-5" style={{ color: '#00ff88' }} />
                      </div>
                      <div>
                        <div className="text-lg font-bold" style={{ color: '#00ff88' }}>{predictorStats?.tiers?.S ?? 0}</div>
                        <div className="text-[10px] text-muted-foreground">S-Tier Elite</div>
                      </div>
                    </motion.div>
                  </div>

                  {/* ── 2. Tier Filter Buttons ─────────────────────────────── */}
                  <div className="flex flex-wrap gap-2">
                    {(['all', 'S', 'A', 'B', 'C', 'D'] as const).map(tier => {
                      const tierMap: Record<string, { color: string; bg: string }> = {
                        all: { color: 'rgba(255,255,255,0.7)', bg: 'rgba(255,255,255,0.06)' },
                        S: { color: '#00ff88', bg: 'rgba(0,255,136,0.15)' },
                        A: { color: '#00d4ff', bg: 'rgba(0,212,255,0.15)' },
                        B: { color: '#a855f7', bg: 'rgba(168,85,247,0.15)' },
                        C: { color: '#f59e0b', bg: 'rgba(245,158,11,0.15)' },
                        D: { color: '#ef4444', bg: 'rgba(239,68,68,0.15)' },
                      }
                      const tc = tierMap[tier]
                      const active = predictorTier === tier
                      const count = tier === 'all'
                        ? store.predictors.length
                        : store.predictors.filter(p => getQualityBadge(p.qualityScore).grade === tier).length
                      return (
                        <button
                          key={tier}
                          onClick={() => setPredictorTier(tier)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border"
                          style={{
                            color: active ? tc.color : 'rgba(255,255,255,0.35)',
                            background: active ? tc.bg : 'transparent',
                            borderColor: active ? tc.color + '40' : 'rgba(255,255,255,0.06)',
                          }}
                        >
                          {tier === 'all' ? 'ALL' : tier}
                          <span className="text-[10px] opacity-60">{count}</span>
                        </button>
                      )
                    })}
                  </div>

                  {/* ── 3. Platform & Search Filters ────────────────────────── */}
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-1 min-w-[200px] max-w-sm">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
                      <Input
                        placeholder="Search predictors..."
                        value={predictorSearch}
                        onChange={(e) => setPredictorSearch(e.target.value)}
                        className="pl-9 h-9 text-xs bg-white/[0.04] border-white/[0.08]"
                      />
                    </div>
                    <Select value={predictorPlatform} onValueChange={setPredictorPlatform}>
                      <SelectTrigger className="w-[130px] h-9 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Platforms</SelectItem>
                        <SelectItem value="telegram">Telegram</SelectItem>
                        <SelectItem value="youtube">YouTube</SelectItem>
                        <SelectItem value="twitter">Twitter</SelectItem>
                        <SelectItem value="discord">Discord</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="flex gap-2 ml-auto">
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-xs border-neon-green/30 text-neon-green hover:bg-neon-green/10"
                        onClick={handleVerifyAll}
                      >
                        <CheckCircle2 className="size-3" />
                        Verify All
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-xs border-neon-red/30 text-neon-red hover:bg-neon-red/10"
                        onClick={handlePruneLowQuality}
                      >
                        <Trash2 className="size-3" />
                        Prune Low
                      </Button>
                    </div>
                  </div>

                  {/* ── 4. Charts Row ──────────────────────────────────────── */}
                  {predictorStats && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Win Rate Distribution */}
                      <div className="glass-card rounded-xl p-4">
                        <h3 className="text-xs font-semibold mb-3 flex items-center gap-2">
                          <BarChart3 className="size-3.5 text-neon-green" />
                          Win Rate Distribution
                        </h3>
                        <div className="h-[180px]">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={predictorStats.winRateDist || []}>
                              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                              <XAxis dataKey="range" tick={{ fontSize: 9, fill: 'rgba(255,255,255,0.4)' }} />
                              <YAxis tick={{ fontSize: 9, fill: 'rgba(255,255,255,0.4)' }} />
                              <RechartsTooltip
                                contentStyle={{ background: 'rgba(0,0,0,0.85)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 11 }}
                              />
                              <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                                {(predictorStats.winRateDist || []).map((_: any, idx: number) => (
                                  <Cell key={idx} fill={['#ef4444', '#f59e0b', '#fb923c', '#00d4ff', '#00ff88'][idx]} />
                                ))}
                              </Bar>
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Platform Pie */}
                      <div className="glass-card rounded-xl p-4">
                        <h3 className="text-xs font-semibold mb-3 flex items-center gap-2">
                          <Radio className="size-3.5 text-neon-blue" />
                          Platform Breakdown
                        </h3>
                        <div className="h-[180px]">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={Object.entries(predictorStats.platforms || {}).map(([name, value]) => ({
                                  name: name.charAt(0).toUpperCase() + name.slice(1),
                                  value: value as number,
                                }))}
                                cx="50%"
                                cy="50%"
                                innerRadius={40}
                                outerRadius={65}
                                dataKey="value"
                                paddingAngle={3}
                              >
                                <Cell fill="#00d4ff" />
                                <Cell fill="#ef4444" />
                                <Cell fill="#a855f7" />
                              </Pie>
                              <RechartsTooltip
                                contentStyle={{ background: 'rgba(0,0,0,0.85)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 11 }}
                              />
                              <Legend
                                iconType="circle"
                                wrapperStyle={{ fontSize: 10, color: 'rgba(255,255,255,0.6)' }}
                              />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Monthly Performance */}
                      <div className="glass-card rounded-xl p-4">
                        <h3 className="text-xs font-semibold mb-3 flex items-center gap-2">
                          <TrendingUp className="size-3.5 text-neon-purple" />
                          Monthly Performance (Top 10)
                        </h3>
                        <div className="h-[180px]">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={(predictorStats.monthlyPerformance || []).filter((m: any) => m.totalTips > 0)}>
                              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                              <XAxis dataKey="month" tick={{ fontSize: 9, fill: 'rgba(255,255,255,0.4)' }} />
                              <YAxis tick={{ fontSize: 9, fill: 'rgba(255,255,255,0.4)' }} domain={[0, 100]} />
                              <RechartsTooltip
                                contentStyle={{ background: 'rgba(0,0,0,0.85)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 11 }}
                              />
                              <Line type="monotone" dataKey="avgWR" stroke="#a855f7" strokeWidth={2} dot={{ fill: '#a855f7', r: 3 }} activeDot={{ r: 5 }} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* ── 5. Enhanced Predictor Cards Grid ───────────────────── */}
                  {store.isLoading.predictors ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {Array.from({ length: 6 }).map((_, i) => (
                        <div key={i} className="glass-card rounded-xl p-4 space-y-3">
                          <div className="flex items-center gap-3">
                            <Skeleton className="h-12 w-12 rounded-xl" />
                            <div className="flex-1 space-y-1">
                              <Skeleton className="h-4 w-24" />
                              <Skeleton className="h-3 w-16" />
                            </div>
                          </div>
                          <Skeleton className="h-3 w-full" />
                          <Skeleton className="h-3 w-3/4" />
                          <div className="flex gap-2">
                            <Skeleton className="h-5 w-12" />
                            <Skeleton className="h-5 w-16" />
                          </div>
                          <div className="grid grid-cols-4 gap-2">
                            {Array.from({ length: 4 }).map((_, j) => (
                              <Skeleton key={j} className="h-10 w-full rounded-md" />
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : filteredPredictors.length > 0 ? (
                    <div className="max-h-[600px] overflow-y-auto custom-scrollbar pr-1">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {filteredPredictors.map((predictor, i) => {
                          const quality = getQualityBadge(predictor.qualityScore)
                          const tags = predictor.tags ? predictor.tags.split(',').map(t => t.trim()).filter(Boolean) : []
                          const platformIcon = predictor.platform === 'telegram' ? '📱' :
                            predictor.platform === 'youtube' ? '🎥' :
                            predictor.platform === 'twitter' ? '🐦' : '💬'
                          return (
                            <motion.div
                              key={predictor.id}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: Math.min(i * 0.03, 0.6) }}
                              className="glass-card rounded-xl p-4 hover:neon-glow-purple transition-all"
                            >
                              {/* Header: Avatar + Name + Platform + Grade */}
                              <div className="flex items-start gap-3 mb-2.5">
                                <div
                                  className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0"
                                  style={{ background: quality.bg }}
                                >
                                  {predictor.avatarEmoji || platformIcon}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-sm font-semibold truncate">{predictor.name}</span>
                                    {predictor.verified && (
                                      <CheckCircle2 className="size-3.5 text-neon-green shrink-0" />
                                    )}
                                  </div>
                                  <div className="flex items-center gap-1.5 mt-0.5">
                                    <span className="text-[10px] text-muted-foreground">
                                      {platformIcon} {predictor.platform}
                                    </span>
                                    {predictor.specialization && (
                                      <Badge
                                        className="text-[9px] px-1.5 py-0 h-4 font-medium"
                                        style={{ background: 'rgba(168,85,247,0.15)', color: '#a855f7', borderWidth: 0 }}
                                      >
                                        {predictor.specialization}
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                                <Badge
                                  className="text-sm font-bold shrink-0 px-2 py-0.5"
                                  style={{ background: quality.bg, color: quality.color, borderWidth: 0 }}
                                >
                                  {quality.grade}
                                </Badge>
                              </div>

                              {/* Bio */}
                              {predictor.bio && (
                                <p className="text-[11px] text-muted-foreground mb-2.5 line-clamp-2 leading-relaxed">
                                  {predictor.bio}
                                </p>
                              )}

                              {/* Quality Score Progress Bar */}
                              <div className="mb-3">
                                <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                                  <span>Quality Score</span>
                                  <span style={{ color: quality.color }}>{predictor.qualityScore.toFixed(0)}/100</span>
                                </div>
                                <div className="h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
                                  <motion.div
                                    className="h-full rounded-full"
                                    style={{ background: quality.color }}
                                    initial={{ width: 0 }}
                                    animate={{ width: `${predictor.qualityScore}%` }}
                                    transition={{ duration: 0.8, delay: Math.min(i * 0.03, 0.6) }}
                                  />
                                </div>
                              </div>

                              {/* Stats Row: Tips | Win Rate | Avg Odds | Streak */}
                              <div className="grid grid-cols-4 gap-1.5 text-center mb-3">
                                <div className="bg-white/[0.03] rounded-md p-1.5">
                                  <div className="text-[11px] font-semibold">{predictor.totalTips}</div>
                                  <div className="text-[8px] text-muted-foreground">Tips</div>
                                </div>
                                <div className="bg-white/[0.03] rounded-md p-1.5">
                                  <div className="text-[11px] font-semibold" style={{ color: predictor.winRate >= 60 ? '#00ff88' : predictor.winRate >= 40 ? '#f59e0b' : '#ef4444' }}>
                                    {predictor.winRate.toFixed(0)}%
                                  </div>
                                  <div className="text-[8px] text-muted-foreground">Win Rate</div>
                                </div>
                                <div className="bg-white/[0.03] rounded-md p-1.5">
                                  <div className="text-[11px] font-semibold">{predictor.avgOdds.toFixed(1)}</div>
                                  <div className="text-[8px] text-muted-foreground">Avg Odds</div>
                                </div>
                                <div className="bg-white/[0.03] rounded-md p-1.5">
                                  <div className="text-[11px] font-semibold" style={{ color: predictor.currentStreak >= 5 ? '#00ff88' : predictor.currentStreak >= 3 ? '#00d4ff' : 'inherit' }}>
                                    {predictor.currentStreak > 0 ? `${predictor.currentStreak}🔥` : '-'}
                                  </div>
                                  <div className="text-[8px] text-muted-foreground">Streak</div>
                                </div>
                              </div>

                              {/* Followers + Tags */}
                              <div className="flex items-center justify-between gap-2">
                                <div className="flex items-center gap-1 text-[10px] text-muted-foreground shrink-0">
                                  <Users className="size-3" />
                                  <span>{predictor.followers >= 1000 ? `${(predictor.followers / 1000).toFixed(1)}k` : predictor.followers}</span>
                                </div>
                                {tags.length > 0 && (
                                  <div className="flex gap-1 flex-wrap justify-end">
                                    {tags.slice(0, 3).map(tag => (
                                      <span
                                        key={tag}
                                        className="text-[9px] px-1.5 py-0.5 rounded-md bg-white/[0.04] text-muted-foreground border border-white/[0.06]"
                                      >
                                        #{tag}
                                      </span>
                                    ))}
                                    {tags.length > 3 && (
                                      <span className="text-[9px] px-1 py-0.5 text-muted-foreground">+{tags.length - 3}</span>
                                    )}
                                  </div>
                                )}
                              </div>
                            </motion.div>
                          )
                        })}
                      </div>
                    </div>
                  ) : (
                    <EmptyState
                      icon={Trophy}
                      title="No Predictors Found"
                      description="No predictors match your current filters. Try adjusting the tier, platform, or search criteria."
                    />
                  )}

                  {/* ── 6. Tag Cloud ───────────────────────────────────────── */}
                  {predictorStats?.tagCloud?.length > 0 && (
                    <div className="glass-card rounded-xl p-4">
                      <h3 className="text-xs font-semibold mb-3 flex items-center gap-2">
                        <Info className="size-3.5 text-neon-orange" />
                        Popular Tags
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {(predictorStats?.tagCloud || []).map((item: { tag: string; count: number }) => (
                          <motion.button
                            key={item.tag}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className="px-3 py-1.5 rounded-lg text-xs bg-white/[0.04] text-muted-foreground border border-white/[0.06] hover:bg-white/[0.08] hover:text-foreground transition-all"
                            onClick={() => setPredictorSearch(item.tag)}
                          >
                            #{item.tag}
                            <span className="ml-1 text-[10px] opacity-50">({item.count})</span>
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* ── 7. Top 10 Leaderboard ──────────────────────────────── */}
                  {predictorStats?.top10?.length > 0 && (
                    <div className="glass-card rounded-xl p-4">
                      <h3 className="text-xs font-semibold mb-3 flex items-center gap-2">
                        <Trophy className="size-3.5 text-yellow-400" />
                        Top 10 Leaderboard
                      </h3>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="border-white/[0.06] hover:bg-transparent">
                              <TableHead className="text-[10px] w-8">#</TableHead>
                              <TableHead className="text-[10px]">Predictor</TableHead>
                              <TableHead className="text-[10px] hidden sm:table-cell">Spec</TableHead>
                              <TableHead className="text-[10px] text-right">Win Rate</TableHead>
                              <TableHead className="text-[10px] text-right hidden sm:table-cell">Tips</TableHead>
                              <TableHead className="text-[10px] text-right">Streak</TableHead>
                              <TableHead className="text-[10px] text-right hidden md:table-cell">Followers</TableHead>
                              <TableHead className="text-[10px] text-center">Grade</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {(predictorStats?.top10 || []).map((p: any, i: number) => {
                              const q = getQualityBadge(p.qualityScore)
                              return (
                                <TableRow key={p.id} className="border-white/[0.04]">
                                  <TableCell className="text-[10px] text-muted-foreground">
                                    {i < 3 ? ['🥇', '🥈', '🥉'][i] : i + 1}
                                  </TableCell>
                                  <TableCell className="text-[11px] font-semibold whitespace-nowrap">
                                    <span className="mr-1">{p.avatarEmoji || '👤'}</span>
                                    {p.name}
                                  </TableCell>
                                  <TableCell className="text-[10px] text-muted-foreground hidden sm:table-cell">
                                    {p.specialization || '-'}
                                  </TableCell>
                                  <TableCell
                                    className="text-[10px] text-right font-semibold"
                                    style={{ color: p.winRate >= 65 ? '#00ff88' : p.winRate >= 50 ? '#00d4ff' : '#f59e0b' }}
                                  >
                                    {p.winRate.toFixed(1)}%
                                  </TableCell>
                                  <TableCell className="text-[10px] text-right text-muted-foreground hidden sm:table-cell">
                                    {p.totalTips}
                                  </TableCell>
                                  <TableCell className="text-[10px] text-right text-muted-foreground">
                                    {p.currentStreak > 0 ? (
                                      <span style={{ color: p.currentStreak >= 5 ? '#00ff88' : '#00d4ff' }}>
                                        {p.currentStreak}🔥
                                      </span>
                                    ) : '-'}
                                  </TableCell>
                                  <TableCell className="text-[10px] text-right text-muted-foreground hidden md:table-cell">
                                    {p.followers >= 1000 ? `${(p.followers / 1000).toFixed(1)}k` : p.followers}
                                  </TableCell>
                                  <TableCell className="text-[10px] text-center">
                                    <Badge
                                      className="text-[10px] px-1.5 py-0 h-4 font-bold"
                                      style={{ background: q.bg, color: q.color, borderWidth: 0 }}
                                    >
                                      {q.grade}
                                    </Badge>
                                  </TableCell>
                                </TableRow>
                              )
                            })}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* ── FOOTER ──────────────────────────────────────────────────────────── */}
      <footer className="relative z-10 border-t border-white/[0.06] backdrop-blur-xl bg-background/60 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
            <span>TT Predict Pro © 2025 | AI-Powered Table Tennis Analytics</span>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-neon-green pulse-live" />
                System Online
              </span>
              <span>v1.0.0</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
