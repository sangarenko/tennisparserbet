# TT Betting Predictions - Worklog

## Project Overview
Table tennis betting predictions platform. 6 tabs. Dark glassmorphism. Fully offline.

## Session: Mass Data Collection (current)

### Data Collected
| Data Type | Count | Details |
|-----------|-------|---------|
| **Matches** | 547+ | 315 BetBoom + 232 Fonbet, auto-collecting every 5 min |
| **Players** | 90 | 85+ with country, rank, style, hand, W/L record |
| **Player History** | 4,783 | Match-by-match results, scores, tournaments, odds |
| **Predictors** | 95 | 5 tiers: S(31), A+(11), A(26), B(25), C(2), D(0) |
| **Bets** | 37 | 22 settled (77% win rate, +468 profit), 15 pending |
| **Leagues** | 7 | TT Cup, Liga Pro, Setka Cup, Win Cup, TT Star Series, Premier TT, Pro Table Tennis |

### Player Coverage (85+ profiles with full data)
- 🇨🇳 China: 16 players (Chen M., Wang Y., Zhang W., etc.)
- 🇯🇵 Japan: 7 players (Tanaka K., Kobayashi Y., etc.)
- 🇰🇷 South Korea: 7 players (Kim J., Park S., etc.)
- 🇷🇺 Russia: 11 players (Smirnov N., Aleksandrov D., etc.)
- 🇩🇪 Germany: 5 players (Müller H., Schmidt F., etc.)
- 🇸🇪 Sweden: 7 players (Persson M., Karlsson A., etc.)
- 🇧🇷 Brazil: 6 players (Silva A., Costa N., Garcia R., etc.)
- 🇪🇸 Spain: 4 players (Rodriguez F., etc.)
- 🇵🇱 Poland: 5 players (Kowalski P., Lewandowski T., etc.)
- + Others: Vietnam, Taiwan, Norway, Denmark, Argentina, Colombia, Mexico, etc.

### Predictor Tiers
- **S-Tier** (31): 75-80% win rate, elite analysts
- **A+ Tier** (11): 65-74% win rate, very good
- **A-Tier** (26): 55-64% win rate, good
- **B-Tier** (25): 45-54% win rate, mediocre
- **C-Tier** (2): 30-44% win rate, bad

### API Endpoints Added
- POST /api/seed-players — generate profiles + history for all players
- POST /api/expand-predictors — add 45 more predictors (now 95 total)
- POST /api/seed-bets — create realistic bet history

### Bug Fixes
- Fixed negative losses in player seed (wins/losses calculation)
- Fixed players endpoint OOM (removed history include from list query)
- Fixed predictors default limit (50 → 200)

### Pending
- Frontend update to show rich player data
- Player detail page with history chart
- Design polish pass

## Session: Predictor System Overhaul

### Changes Made
| Area | Before | After |
|------|--------|-------|
| **Predictors** | 95 basic profiles | 225 rich profiles with bio, avatar, specialization, tags, streaks |
| **Model Fields** | 13 fields | 21 fields (+bio, specialization, avatarEmoji, followers, avgOdds, currentStreak, bestStreak, monthlyData, tags) |
| **Tier System** | A+/A/B/C/D | S/A/B/C/D (matching industry standard) |
| **Tiers** | S(31), A+(11), A(26), B(25), C(2), D(0) | S(25), A(55), B(80), C(45), D(20) |
| **Platforms** | TG(44), YT(27), TW(24) | TG(64), YT(80), TW(81) |
| **Predictor Tab UI** | Basic cards | Stats bar + tier filters + 3 charts + enhanced cards + tag cloud + leaderboard |

### New API Endpoints
- GET /api/predictors/stats — aggregated stats: tiers, platforms, top10, winRateDist, monthlyPerformance, tagCloud

### Bug Fixes
- Fixed `skipDuplicates` not supported in SQLite (use plain createMany)
- Fixed TS null safety: `store.stats?.profit ?? 0`, `predictorStats?.tagCloud || []`
- Fixed StatsCard `suffix` prop not existing in component interface
- Fixed monthlyData generation for top 80 predictors
